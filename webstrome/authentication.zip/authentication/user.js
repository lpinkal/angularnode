var mongooose=require('mongoose');
var validator=require('validator');
var jwt=require('jsonwebtoken');
var userschema=new mongooose.Schema({
   email:{
       type:String,
       required:true,
       trim:true,
       minlength:1,
       unique:true,
       validate:{
           validator:validator.isEmail,
           message:`{value} not valid`
       }
   },
    password:{
       type:String,
        minlength:6,
        required:true
    },
    tokens:[{
       access:{
           type:String,
           required:true
       },
token:{
           type:String,
    required:true
}
    }]
});

userschema.methods.generateAuthToken=function () {
    var user=this;
    var access='auth';
    var token=jwt.sign({_id:user._id.toHexString(),access},'abc123').toString();

    user.tokens.push({access,token});

    return user.save().then(()=>{
        return token;
    });
};


var user=mongooose.model('user',userschema);




module.exports={user};