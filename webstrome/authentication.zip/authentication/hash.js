const jwt=require('jsonwebtoken');
var data={
    id:4
}
let a=jwt.sign(data,'abc1234');
let b=jwt.verify(a,'abc1234');

console.log(a);
console.log(b);


















//
// const {SHA256}=require('crypto-js');
// // let msg='javascript';
// //
// // let hash=SHA256(msg).toString();
// // console.log(msg);
// // console.log(hash);
//
// var data={
//    id:4
// };
//
// var token={
//     data,
//     hash: SHA256(JSON.stringify(data)+'something').toString()
// }
//
// // token.data.id=5;
// // token.hash=SHA256(JSON.stringify(token.data)).toString();
//
// var crypt=SHA256(JSON.stringify(token.data)+'something').toString();
//
// if(crypt===token.hash){
//     console.log('not changed');
// }else{
//     console.log('changed');
// }