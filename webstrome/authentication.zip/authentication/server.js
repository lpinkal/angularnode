const express=require('express');
const bodyparser=require('body-parser');
const {user}=require('./user');
const {mongoose}=require('./connect');
const _=require('lodash');

var app=express();
app.use(bodyparser.json());

app.post('/post',(req,res)=>{

        var body=_.pick(req.body,['email','password']);
        var user1=new user(body);

        user1.save().then((user1)=>{
            // res.send('ans'+user);
            return user1.generateAuthToken();
        }).then((token)=>{
            res.header('x-auth',token).send(user1);
        }).catch((e)=>{
            res.send('error'+e);
        })
});

app.listen(3000,()=>{
    console.log('server started on port number 3000');
});